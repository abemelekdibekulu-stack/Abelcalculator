const display = document.getElementById('display');

// Append numbers or operators
function append(value) {
  display.value += value;
}

// Clear all input
function clearDisplay() {
  display.value = '';
}

// Calculate expression
function calculate() {
  try {
    display.value = eval(display.value);
  } catch {
    display.value = 'Error';
  }
}

// Delete last character (Backspace)
function backspace() {
  display.value = display.value.slice(0, -1);
}

// Toggle between positive and negative
function toggleSign() {
  if (display.value) {
    if (display.value.startsWith('-')) {
      display.value = display.value.substring(1);
    } else {
      display.value = '-' + display.value;
    }
  }
}
const display = document.getElementById('display');

// Append numbers or operators
function append(value) {
  display.value += value;
}

// Clear all input
function clearDisplay() {
  display.value = '';
}

// Calculate expression
function calculate() {
  try {
    display.value = eval(display.value);
  } catch {
    display.value = 'Error';
  }
}

// Delete last character (Backspace)
function backspace() {
  display.value = display.value.slice(0, -1);
}

// Toggle between positive and negative
function toggleSign() {
  if (display.value) {
    if (display.value.startsWith('-')) {
      display.value = display.value.substring(1);
    } else {
      display.value = '-' + display.value;
    }
  }
}

// Real-time clock
function updateClock() {
  const clock = document.getElementById('clock');
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  clock.textContent = `${hours}:${minutes}:${seconds}`;
}

setInterval(updateClock, 1000);
updateClock();
